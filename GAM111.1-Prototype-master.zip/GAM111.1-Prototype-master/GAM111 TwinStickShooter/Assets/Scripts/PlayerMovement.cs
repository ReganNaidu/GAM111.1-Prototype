﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody myRigidbody;
    public float moveSpeed;
    private Vector3 moveInput;
    private Vector3 moveVelocity;

    private Camera mainCamera;
    public float speedTimer;
    public float speedTimerReset;
    public GunControl theGun;
    public bool isSpeed;
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody>();
        mainCamera = FindObjectOfType<Camera>();
        speedTimerReset = speedTimer;
    }


    void Update()
    {
        moveInput = new Vector3(Input.GetAxisRaw("Horizontal"), 0f, Input.GetAxisRaw("Vertical"));
        moveVelocity = moveInput * moveSpeed;

        Ray cameraRay = mainCamera.ScreenPointToRay(Input.mousePosition);
        Plane groundPlane = new Plane(Vector3.up, Vector3.zero);
        float rayLength;

        if (groundPlane.Raycast(cameraRay, out rayLength))
        {
            Vector3 pointToLook = cameraRay.GetPoint(rayLength);
            Debug.DrawLine(cameraRay.origin, pointToLook, Color.blue);

            transform.LookAt(new Vector3(pointToLook.x, transform.position.y, pointToLook.z));
        }
        if (Input.GetMouseButtonDown(0) || theGun.isFiring)
        {
            theGun.isFiring = true;
        }
        if (Input.GetMouseButtonUp(0))
        {
            theGun.isFiring = false;
        }
        if (Input.GetMouseButtonDown(1) || theGun.isFiring2)
        {
            theGun.isFiring2 = true;
        }
        if (Input.GetMouseButtonUp(1))
        {
            theGun.isFiring2 = false;
        }
        if (Input.GetMouseButtonDown(0))
        {
            theGun.isFiring3 = true;
        }
        if (Input.GetMouseButtonUp(0))
        {
            theGun.isFiring3 = false;
        }
        if (isSpeed == true)
        {
            moveSpeed = 10;
            speedTimer -= Time.deltaTime;
        }
        if (speedTimer <= 0)
        {
            moveSpeed = 5;
            isSpeed = false;
            speedTimer = speedTimerReset;
            
        }
    }
    void FixedUpdate()
    {
        myRigidbody.velocity = moveVelocity;
    }
    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "SpeedBoost")
        {
 

            isSpeed = true;
            Destroy(other.gameObject);
        }   
    }
}
