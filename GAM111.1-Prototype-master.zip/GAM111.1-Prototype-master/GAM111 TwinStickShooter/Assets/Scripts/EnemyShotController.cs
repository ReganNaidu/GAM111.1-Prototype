﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShotController : MonoBehaviour
{
    public float moveSpeed;

    public Transform player;

    public Vector3 targetDirection;
    private float shotTimer;
    public float shotDestroyTime;
	void Start ()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;

        targetDirection = player.position - transform.position;
        targetDirection.Normalize();
        shotTimer = shotDestroyTime;
	}
	void Update ()
    {
        shotTimer -= Time.deltaTime;
        if(shotTimer <= 0)
        {
            Destroy(gameObject);
        }
        transform.position += targetDirection *moveSpeed * Time.deltaTime;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            DestroyBullet();
        }
        if (other.CompareTag("Wall"))
        {
            DestroyBullet();
        }
    }
    void DestroyBullet()
    {
        Destroy(gameObject);
    }
}