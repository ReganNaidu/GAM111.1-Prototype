﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public int totalScore;
    public float scoreTimer;
    public Text scoreText;
    public float scoreTimerReset;
    private void Start()
    {
        scoreTimerReset = scoreTimer;
    }
    private void Update()
    {
        scoreTimer -= Time.deltaTime;
        if (scoreTimer <=0)
        {

            totalScore += 1;
            scoreText.text ="Score: " + totalScore.ToString();
            scoreTimer = scoreTimerReset;
        }
    }

}
