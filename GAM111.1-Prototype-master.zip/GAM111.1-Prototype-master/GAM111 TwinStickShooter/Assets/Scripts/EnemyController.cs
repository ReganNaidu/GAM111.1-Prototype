﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    private Rigidbody myRB;
    public float moveSpeed;

    public PlayerMovement thePlayer;

	void Start ()
    {
        myRB = GetComponent<Rigidbody>();
        thePlayer = FindObjectOfType<PlayerMovement>();
	}

    void FixedUpdate()
    {
        myRB.velocity = (transform.forward * moveSpeed);
    }
    void Update ()
    {
        transform.LookAt(thePlayer.transform.position);
	}
}
