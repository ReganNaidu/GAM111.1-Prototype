﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeSpawner : MonoBehaviour
{
    public GameObject spawnee1;
    public GameObject spawnee2;
    public GameObject spawnee3;
    public bool stopSpawning;
    public float spawnTime;
    public float spawnDelay1;
    public float spawnDelay2;
    public float spawnDelay3;
    void Start ()
    {
        InvokeRepeating("SpawnObject1", spawnTime, spawnDelay1);
        InvokeRepeating("SpawnObject2", spawnTime, spawnDelay2);
        InvokeRepeating("SpawnObject3", spawnTime, spawnDelay3);
    }
    public void SpawnObject1()
    {
        Instantiate(spawnee1, transform.position, transform.rotation);
        spawnDelay1 -= 0.1f;
        if (stopSpawning)
        {
            CancelInvoke("SpawnObject");
        }
    }
    public void SpawnObject2()
    {
        Instantiate(spawnee2, transform.position, transform.rotation);
        spawnDelay2 -= 0.1f;
        if (stopSpawning)
        {
            CancelInvoke("SpawnObject");
        }
    }
    public void SpawnObject3()
    {
        Instantiate(spawnee3, transform.position, transform.rotation);
        spawnDelay3 -= 0.1f;
        if (stopSpawning)
        {
            CancelInvoke("SpawnObject");
        }
    }
}
