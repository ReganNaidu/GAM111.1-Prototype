﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealthManager : MonoBehaviour
{
    public int startingHealth;
    public int currentHealth;

    public float flashLength;
    private float flashCounter;

    private Renderer rend;
    private Color storedColor;

    private Text playerHealth;
    
	void Start ()
    {
        currentHealth = startingHealth;
        rend = GetComponent<Renderer>();
        storedColor = rend.material.GetColor("_Color");

	}
	

	void Update ()
    {
		if(currentHealth <=0)
        {
            SceneManager.LoadScene("Dead");
        }
        if(flashCounter > 0)
        {
            flashCounter -= Time.deltaTime;
            if(flashCounter <=0)
            {
                rend.material.SetColor("_Color", storedColor);
            }
        }
        if(currentHealth > 10)
        {
            currentHealth = 10;
        }
	}
    public void HurtPlayer(int damageAmount)
    {
        currentHealth -= damageAmount;
        flashCounter = flashLength;
        rend.material.SetColor("_Color", Color.white);
    }
    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            currentHealth -= 1;

        }
        if (other.gameObject.tag == "HealthPickup")
        {
            currentHealth += 5;
            Destroy(other.gameObject);
        }

    }
}
