﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunControl : MonoBehaviour
{
    public bool isFiring;
    public float bulletSpeed;
    public float timeBetweenShots;
    private float shotCounter;
    public BulletController bullet;

    public bool isFiring2;
    public float cannonSpeed;
    public float timeBetweenShots2;
    public float shotCounter2;
    public BulletController cannonBall;

    public bool isFiring3;
    public float trackSpeed;
    public float timeBetweenShots3;
    public float shotCounter3;
    public TrackBullet trackShot;

    public Transform firePoint;

	void Update ()
    {
        if (isFiring)
        {
            shotCounter -= Time.deltaTime;
            if (shotCounter <= 0)
            {
                shotCounter = timeBetweenShots;
                BulletController newBullet = Instantiate(bullet, firePoint.position, firePoint.rotation) as BulletController;
                newBullet.speed = bulletSpeed;
            }
        }
        else
        {
            shotCounter -= Time.deltaTime;
        }

        if (isFiring2)
        {
            shotCounter2 -= Time.deltaTime;
            if (shotCounter2 <= 0)
            {
                shotCounter2 = timeBetweenShots2;
                BulletController newcannonBall = Instantiate(cannonBall, firePoint.position, firePoint.rotation) as BulletController;
                newcannonBall.speed = cannonSpeed;
            }
        }
        else
        {
            shotCounter2 -= Time.deltaTime;
        }
        if (isFiring3)
        {
            shotCounter3 -= Time.deltaTime;
            if (shotCounter3 <= 0)
            {
                shotCounter3 = timeBetweenShots3;
                TrackBullet newTrackShot = Instantiate(trackShot, firePoint.position, firePoint.rotation) as TrackBullet;
                newTrackShot.moveSpeed = trackSpeed;
            }
        }
        else
        {
            shotCounter3 -= Time.deltaTime;
        }
    }

}
